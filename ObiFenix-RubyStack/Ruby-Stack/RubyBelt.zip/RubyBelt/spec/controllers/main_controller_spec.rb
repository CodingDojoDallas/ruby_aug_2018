require 'rails_helper'

RSpec.describe MainController, type: :controller do

end
