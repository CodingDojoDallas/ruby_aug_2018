FactoryBot.define do
  factory :playlist do
    user_id 1
    song_id 1
  end
end
