FactoryBot.define do
  factory :song do
    title "MyString"
    artist "MyString"
    user_id 1
  end
end
