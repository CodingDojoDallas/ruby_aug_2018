class Human
  attr_accessor :health
  def initialize(stren=3, intel=3, stealth=3, health=100)
    @stren = stren
    @intel = intel
    @stealth = stealth
    @health = health
  end

  def attack object
    object.health -= 5 if object.instance_of? Human
    puts "good job you decreased health to #{object.health}"
    self
  end
end

zack = Human.new
billy = Human.new.attack(zack)
