class DojosController < ApplicationController
  def index
    @all_dojos = Dojo.all
  end
end
