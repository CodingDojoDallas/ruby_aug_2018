class HelloController < ApplicationController
  def index
    render text: "Hello CodingDojo"
  end
end
