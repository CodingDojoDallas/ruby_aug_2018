class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception

  def current_user
    User.find(session[:user_id]) if session[:user_id]
  end

  def require_login
    redirect_to "/sessions/new" unless session[:user_id]
  end

  def user_valid
    unless params[:id].to_d == session[:user_id].to_d
      redirect_to "/users/#{session[:user_id]}"
    end
  end

  helper_method :current_user, :require_login, :user_valid
end
