require "rails_helper"
feature "Restricting user mobility" do
  before do
    create(:user)
    visit "/sessions/new"
  end

  scenario "user cannot go to /secrets if they are not logged in" do
    visit "/secrets"
    expect(current_path).to eq("/sessions/new")
  end

  scenario "user can go to /users/new if they are not logged in" do
    visit "/users/new"
    expect(current_path).to eq("/users/new")
  end
end
