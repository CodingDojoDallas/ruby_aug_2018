FactoryBot.define do
  factory :secret do
    content "This is my secret!"
    user nil
  end
end
