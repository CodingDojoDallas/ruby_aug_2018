class SecretsController < ApplicationController
  def index
    @all_secrets = Secret.all
  end

  def create
    new_secret = Secret.create(secret_params.merge({ user_id: current_user.id }))
    if new_secret.valid?
      redirect_to "/users/#{current_user.id}"
    else
      flash[:errors] = new_secret.errors.full_messages
      redirect_to "/users/#{current_user.id}"
    end
  end

  def destroy
    secret = current_user.secrets.find(params[:id])
    secret.destroy
    redirect_to "/users/#{current_user.id}"
  end

  private
    def secret_params
      params.require(:secret).permit(:content)
    end
end
