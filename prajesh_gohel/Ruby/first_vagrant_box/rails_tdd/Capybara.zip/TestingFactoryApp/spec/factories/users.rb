FactoryBot.define do
  factory :user do
    first_name "Prajesh"
    last_name "Gohel"
    email "prajeshgohel@gmail.com"
  end
end
