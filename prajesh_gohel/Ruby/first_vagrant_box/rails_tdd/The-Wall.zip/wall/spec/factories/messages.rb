FactoryBot.define do
  factory :message do
    message "this is the greatest message ever"
    user
  end
end
