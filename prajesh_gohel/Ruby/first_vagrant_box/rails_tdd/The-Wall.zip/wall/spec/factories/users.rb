FactoryBot.define do
  factory :user do
    first_name "Bob"
    last_name "Chicken"
    email "bob@chicken.com"
    username "mcbobster21"
  end
end
